# Política de tratamiento de datos personales

Fintrex S.A.S. es responsable del tratamiento de los datos personales de sus
clientes. Los datos se usan para prestar los servicios financieros contratados,
verificar la identidad del cliente y atender sus solicitudes.

Los titulares pueden escribir a datos@fintrex.example.
