# Fintrex — portal de clientes

Portal web de Fintrex S.A.S. (empresa ficticia) generado con herramientas de
vibecoding: vinculación digital con selfie y cédula, consulta de productos y un
asistente de chat para clientes.

Stack: Next.js, Supabase y proveedores de modelos de lenguaje.

```bash
npm install
cp .env.example .env.local
npm run dev
```
