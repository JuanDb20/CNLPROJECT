"use client";

import { ChatComposer } from "@/components/chat-composer";
import { ChatHeader } from "@/components/chat-header";
import { ConsentPanel } from "@/components/consent-panel";
import { useCustomer } from "@/lib/use-customer";

export default function ChatPage() {
  const customer = useCustomer();
  console.log("customer", customer);

  return (
    <main className="mx-auto flex h-dvh max-w-xl flex-col">
      <ChatHeader title="Equipo Fintrex" />
      <ConsentPanel />
      <ChatComposer />
    </main>
  );
}
