import { runAgent } from "@/agent/runtime";

export const runtime = "edge";

export async function POST(request: Request) {
  const { message, customerId } = await request.json();
  const reply = await runAgent(message, customerId);
  return Response.json({ reply });
}
