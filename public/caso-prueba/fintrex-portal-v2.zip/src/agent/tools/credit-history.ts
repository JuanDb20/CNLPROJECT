import { defineTool } from "../define-tool";

// Consulta el historial crediticio del titular en la central de riesgo
export const creditHistory = defineTool({
  name: "credit_history",
  description: "Comportamiento de pago del titular: moras, cupos y puntaje",
  requireDocument: true,
  async run(args: { document: string }) {
    const response = await fetch(`https://centralderiesgo.example/api/reportes/${args.document}`);
    const report = await response.json();
    return { moras: report.delinquencies, cupo: report.approvedLimit, puntaje: report.score };
  },
});
