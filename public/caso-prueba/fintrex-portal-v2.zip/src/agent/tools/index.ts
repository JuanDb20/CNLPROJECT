import { creditHistory } from "./credit-history";
import { customerRecord } from "./customer-record";

export const tools = [
  customerRecord,
  creditHistory,
];
