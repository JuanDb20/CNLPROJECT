import { db } from "@/lib/db";
import { AccessDenied, getSession } from "@/lib/session";

import { defineTool } from "../define-tool";

// Consulta el expediente del titular que inició sesión. El permiso se verifica
// en el código, no en el prompt, y nunca se entregan campos biométricos al modelo.
export const customerRecord = defineTool({
  name: "customer_record",
  description: "Devuelve el registro de vinculación del cliente que inició sesión",
  async run() {
    const session = await getSession();
    if (!session) throw new AccessDenied();
    const record = await db.customers.findByUserId(session.user.id);
    return { name: record.full_name, match_score: record.kyc_documents.match_score };
  },
});
