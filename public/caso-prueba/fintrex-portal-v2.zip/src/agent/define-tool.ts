export interface ToolDefinition<A> {
  name: string;
  description: string;
  requireDocument?: boolean;
  run: (args: A) => Promise<unknown>;
}

export function defineTool<A>(definition: ToolDefinition<A>) {
  return definition;
}
