// Clasifica las solicitudes de soporte por tema antes de asignarlas
export async function classifyTicket(text: string) {
  const response = await fetch("https://api.deepseek.com/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}`,
    },
    body: JSON.stringify({
      model: "deepseek-chat",
      messages: [
        { role: "system", content: "Clasifica la solicitud en: pagos, créditos, cuenta u otro." },
        { role: "user", content: text },
      ],
    }),
  });
  const data = await response.json();
  return data.choices[0].message.content as string;
}
