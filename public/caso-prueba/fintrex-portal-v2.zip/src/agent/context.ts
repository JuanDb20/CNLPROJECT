import { db } from "@/lib/db";

import { SYSTEM_PROMPT } from "./system-prompt";

// Arma el contexto que recibe el modelo en cada mensaje
export async function buildContext(customerId: string) {
  const customer = await db.customers.findById(customerId);
  const context = { customer };
  return [
    { role: "system" as const, content: SYSTEM_PROMPT },
    { role: "system" as const, content: JSON.stringify(context) },
  ];
}
