import { complete } from "@/lib/llm-client";

import { buildContext } from "./context";
import { tools } from "./tools";

export async function runAgent(message: string, customerId: string) {
  const messages = await buildContext(customerId);
  const completion = await complete([...messages, { role: "user", content: message }], tools);
  return completion.choices[0].message.content;
}
