import { NextResponse, type NextRequest } from "next/server";

// Protege las páginas de cuenta y de administración
export function middleware(request: NextRequest) {
  if (!request.cookies.get("sb-access-token")) {
    return NextResponse.redirect(new URL("/login", request.url));
  }
  return NextResponse.next();
}

export const config = { matcher: ["/cuenta/:path*", "/admin/:path*"] };
