import OpenAI from "openai";

// Cliente del modelo para el chat del portal
export const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY, // solo en el servidor
});

export async function complete(messages: OpenAI.ChatCompletionMessageParam[], tools: unknown[]) {
  return openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages,
    tools: tools as OpenAI.ChatCompletionTool[],
  });
}
