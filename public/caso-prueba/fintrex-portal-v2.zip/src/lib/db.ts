import { supabase } from "./supabase";

export const db = {
  customers: {
    async findById(id: string) {
      const { data } = await supabase.from("customers").select("*").eq("id", id).single();
      return data;
    },
    async findByDocument(document: string) {
      const { data } = await supabase
        .from("customers")
        .select("*, kyc_documents(*)")
        .eq("document_number", document)
        .single();
      return data;
    },
  },
};
