"use client";

import { useEffect, useState } from "react";

export function useCustomer() {
  const [customer, setCustomer] = useState<Record<string, unknown> | null>(null);
  useEffect(() => {
    fetch("/api/me").then((r) => r.json()).then(setCustomer);
  }, []);
  return customer;
}
