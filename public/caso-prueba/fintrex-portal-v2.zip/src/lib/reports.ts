import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Genera el resumen mensual que se envía a cada cliente
export async function monthlyReport(customer: { full_name: string; products: string[] }) {
  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-5",
    max_tokens: 800,
    messages: [
      {
        role: "user",
        content: `Resume los movimientos del mes de ${customer.full_name}: ${customer.products.join(", ")}`,
      },
    ],
  });
  return response.content;
}
