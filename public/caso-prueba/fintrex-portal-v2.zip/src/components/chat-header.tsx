export function ChatHeader({ title }: { title: string }) {
  return (
    <header className="border-b p-4">
      <h1 className="font-semibold">{title}</h1>
      <p className="text-sm text-gray-500">En línea</p>
    </header>
  );
}
