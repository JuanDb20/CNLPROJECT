"use client";

import { useState } from "react";

export function ChatComposer() {
  const [message, setMessage] = useState("");

  async function send() {
    await fetch("/api/chat", { method: "POST", body: JSON.stringify({ message }) });
    setMessage("");
  }

  return (
    <div className="mt-auto flex gap-2 border-t p-3">
      <textarea value={message} onChange={(e) => setMessage(e.target.value)} className="flex-1" />
      <button onClick={send}>Enviar</button>
    </div>
  );
}
