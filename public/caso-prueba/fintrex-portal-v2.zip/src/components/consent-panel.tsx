"use client";

import { AcceptButton, CollapsedMenu, RevokeButton } from "./buttons";

export function ConsentPanel() {
  return (
    <section className="m-3 rounded border p-3 text-sm">
      <p>Autorizo el tratamiento de mis datos para recibir atención personalizada.</p>
      <AcceptButton variant="primary">Aceptar</AcceptButton>
      <CollapsedMenu label="Más opciones">
        <CollapsedMenu label="Configuración de datos">
          <RevokeButton variant="link" />
        </CollapsedMenu>
      </CollapsedMenu>
    </section>
  );
}
