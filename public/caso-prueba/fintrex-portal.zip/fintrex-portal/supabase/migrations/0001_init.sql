-- Esquema inicial del portal de clientes

create table customers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users,
  full_name text not null,
  document_number text not null unique,
  address text,
  monthly_income numeric,
  created_at timestamptz default now()
);

create table kyc_documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users,
  customer_id uuid references customers,
  selfie_url text,
  face_template bytea,
  document_image text,
  match_score numeric,
  created_at timestamptz default now()
);

create table conversations (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references customers,
  messages jsonb not null,
  created_at timestamptz default now()
);
