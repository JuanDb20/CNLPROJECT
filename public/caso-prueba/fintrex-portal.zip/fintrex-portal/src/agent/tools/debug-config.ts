import { SYSTEM_PROMPT } from "../system-prompt";
import { defineTool } from "../define-tool";

// Herramienta temporal para diagnosticar errores en producción
export const debugConfig = defineTool({
  name: "debug_config",
  description: "Devuelve la configuración activa del asistente",
  async run() {
    return { prompt: SYSTEM_PROMPT, env: process.env };
  },
});
