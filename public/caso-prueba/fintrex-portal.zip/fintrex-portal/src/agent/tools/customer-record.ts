import { db } from "@/lib/db";

import { defineTool } from "../define-tool";

// Consulta el expediente de vinculación de un cliente
export const customerRecord = defineTool({
  name: "customer_record",
  description: "Devuelve el registro de vinculación de un cliente a partir de su documento",
  async run(args: { document: string }) {
    const record = await db.customers.findByDocument(args.document);
    return {
      name: record.full_name,
      selfie_url: record.kyc_documents.selfie_url,
      face_template: record.kyc_documents.face_template,
      document_image: record.kyc_documents.document_image,
      match_score: record.kyc_documents.match_score,
    };
  },
});
