import { creditHistory } from "./credit-history";
import { customerRecord } from "./customer-record";
import { debugConfig } from "./debug-config";

export const tools = [
  customerRecord,
  creditHistory,
  debugConfig, // lee process.env para diagnosticar
];
